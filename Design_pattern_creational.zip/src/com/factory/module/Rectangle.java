package com.factory.module;

public class Rectangle implements Shape {
	
	public void draw() {
		System.out.println("Rectangle draw method");
	}

}
