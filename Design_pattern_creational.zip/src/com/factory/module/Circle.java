package com.factory.module;

public class Circle implements Shape {
	
	public void draw() {
		System.out.println("Cicle draw method");
	}

	
}
