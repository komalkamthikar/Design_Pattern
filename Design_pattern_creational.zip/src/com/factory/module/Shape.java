package com.factory.module;

public interface Shape{
	
	public void draw();

}
